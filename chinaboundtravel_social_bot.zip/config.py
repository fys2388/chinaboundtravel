# ============================================
# chinaboundtravel.com Social Media Bot - Configuration
# ============================================
# Author: Joran (California native, Chengdu son-in-law)
# Blog: https://chinaboundtravel.com
# ============================================

import os
from datetime import time

# ------------------------
# Blogger Identity
# ------------------------
BLOG_NAME = "ChinaBound Travel"
BLOG_URL = "https://chinaboundtravel.com"
BLOG_RSS = "https://chinaboundtravel.com/index.xml"
AUTHOR_NAME = "Joran"
AUTHOR_BIO = "A California native married to a Chengdu local, Joran has been traveling across China for over 10 years. He shares practical, up-to-date travel advice for international visitors looking to explore China authentically."

# ------------------------
# Posting Schedule (Beijing Time)
# ------------------------
POSTING_TIMES = [
    time(hour=10, minute=0),  # 10:00 AM
    time(hour=16, minute=0),  # 4:00 PM
]

# Intervals (seconds)
INTER_PLATFORM_DELAY = 60    # Gap between different platforms
SAME_PLATFORM_DELAY = 300   # Gap between posts on same platform

# Daily Limits
DAILY_LIMITS = {
    "reddit": 3,
    "pinterest": 10,
    "quora": 5,
    "medium": 2,
}

# ------------------------
# Reddit Configuration
# ------------------------
REDDIT_CONFIG = {
    # Get from: https://www.reddit.com/prefs/apps
    "client_id": "YOUR_REDDIT_CLIENT_ID",
    "client_secret": "YOUR_REDDIT_CLIENT_SECRET",
    "username": "YOUR_REDDIT_USERNAME",
    "password": "YOUR_REDDIT_PASSWORD",
    "user_agent": "ChinaBoundTravel/1.0 (by /u/YOUR_USERNAME)",

    # Target subreddits for China travel content
    "subreddits": [
        "travel",
        "solotravel",
        "backpacking",
        "China",
        "Sichuan",
        "backpacking",
        "digitalnomad",
    ],

    # Reddit strict rule: NO external links allowed
    # Must use this fixed诱导文案
    "no_link_message": "I wrote a fully detailed guide on my blog. Comment 'GUIDE' below, and I'll DM you the link.",

    # Flair options
    "flair_id": "",  # Optional: Your subreddit's post flair ID
}

# ------------------------
# Pinterest Configuration
# ------------------------
PINTEREST_CONFIG = {
    # Get from: https://developers.pinterest.com/apps/
    "app_id": "YOUR_PINTEREST_APP_ID",
    "app_secret": "YOUR_PINTEREST_APP_SECRET",
    "access_token": "YOUR_PINTEREST_ACCESS_TOKEN",
    "refresh_token": "YOUR_PINTEREST_REFRESH_TOKEN",

    # Board names (create these on Pinterest first)
    "boards": [
        "China Travel Guide",
        "Chengdu Travel",
        "China Visa Guide",
        "China Payment Apps",
        "China Internet & VPN",
        "China Food & Culture",
        "Sichuan Travel",
        "Shanghai Travel",
    ],

    # Board IDs (get from Pinterest API)
    "board_ids": {
        "China Travel Guide": "YOUR_BOARD_ID_1",
        "Chengdu Travel": "YOUR_BOARD_ID_2",
        "China Visa Guide": "YOUR_BOARD_ID_3",
        "China Payment Apps": "YOUR_BOARD_ID_4",
        "China Internet & VPN": "YOUR_BOARD_ID_5",
        "China Food & Culture": "YOUR_BOARD_ID_6",
        "Sichuan Travel": "YOUR_BOARD_ID_7",
        "Shanghai Travel": "YOUR_BOARD_ID_8",
    },

    # Image settings
    "image_width": 1000,
    "image_height": 1500,
}

# ------------------------
# Quora Configuration
# ------------------------
QUORA_CONFIG = {
    # Get from: https://www.quora.com/settings/security
    "email": "YOUR_QUORA_EMAIL",
    "password": "YOUR_QUORA_PASSWORD",

    # Cookies (recommended for better stability)
    "m_bc": "YOUR_M_BC_COOKIE",      # Required
    "m_s": "YOUR_M_S_COOKIE",        # Required
    "m_ts": "YOUR_M_TS_COOKIE",      # Required

    # Topics to follow (China travel related)
    "topics": [
        "China",
        "Travel",
        "Solo Travel",
        "Backpacking",
        "Chengdu",
        "Visa",
        "International Travel",
    ],

    # Spaces to answer
    "spaces": [
        "Travel to China",
        "China Visa Guide",
        "Solo Travel Asia",
    ],
}

# ------------------------
# Medium Configuration
# ------------------------
MEDIUM_CONFIG = {
    # Get from: https://medium.com/me/settings/security
    "integration_token": "YOUR_MEDIUM_INTEGRATION_TOKEN",
    "user_id": "YOUR_MEDIUM_USER_ID",  # Get from https://api.medium.com/v1/me

    # Publications (optional)
    "publications": {
        "Travel": "YOUR_PUBLICATION_ID_1",
    },

    # Tags for articles
    "default_tags": [
        "travel",
        "china",
        "sichuan",
        "chengdu",
        "chinatravel",
        "backpacking",
        "solotravel",
    ],
}

# ------------------------
# Content Templates
# ------------------------
CONTENT_TEMPLATES = {
    "reddit": {
        "title_template": "{title} - A Practical Guide from a 10-Year China Resident",
        "body_template": """
Hey fellow travelers!

I'm Joran, a California native married into a Chengdu family. After 10 years exploring China, I wanted to share some practical insights that would have saved me tons of headaches.

**What I cover in my full guide:**
- Step-by-step instructions that actually work
- Real costs and time estimates
- Common mistakes to avoid
- Updated for 2026

{summary}

{no_link_message}

Feel free to ask me anything about traveling in China! I've helped hundreds of travelers navigate these exact challenges.

Safe travels!
-Joran
""",
    },

    "pinterest": {
        "title_template": "{title} | China Travel Tips 2026",
        "description_template": """
A practical guide to {topic} in China, written by a 10-year resident. Perfect for backpackers, solo travelers, and first-time visitors.

Save this for your China trip! #ChinaTravel #Backpacking #SoloTravel
""",
    },

    "quora": {
        "answer_template": """
Based on my 10 years of living and traveling in China as a foreign resident, here's what works in 2026:

{answer_content}

I wrote a comprehensive guide on my blog that covers all the details. Feel free to follow me for more China travel tips!
""",
    },

    "medium": {
        "title_template": "{title} - The Complete 2026 Guide",
        "subtitle_template": "Practical advice from a 10-year China resident",
        "tags_template": ["china-travel", "travel-guide", "2026", "{topic}"],
    },
}

# ------------------------
# Error Handling
# ------------------------
RETRY_CONFIG = {
    "max_retries": 3,
    "retry_delay": 30,  # seconds
    "backoff_multiplier": 2,
}

ERROR_NOTIFICATION = {
    "enabled": False,
    "email": "YOUR_EMAIL@example.com",
}

# ------------------------
# Logging
# ------------------------
LOG_CONFIG = {
    "level": "INFO",
    "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    "file": "social_bot.log",
    "max_bytes": 10 * 1024 * 1024,  # 10MB
    "backup_count": 5,
}

# ------------------------
# File Paths
# ------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONTENT_DIR = os.path.join(BASE_DIR, "content")
TEMPLATES_DIR = os.path.join(CONTENT_DIR, "templates")
POSTS_FILE = os.path.join(CONTENT_DIR, "initial_posts.csv")

# ------------------------
# Platform Keywords Mapping
# ------------------------
# Maps content topics to appropriate platforms
TOPIC_PLATFORM_MAP = {
    "visa": ["reddit", "quora", "medium", "pinterest"],
    "payment": ["reddit", "quora", "medium", "pinterest"],
    "internet": ["reddit", "quora", "medium", "pinterest"],
    "transportation": ["reddit", "quora", "medium", "pinterest"],
    "food": ["reddit", "pinterest"],
    "culture": ["reddit", "quora", "medium", "pinterest"],
    "city_guide": ["reddit", "quora", "medium", "pinterest"],
    "travel_tips": ["reddit", "quora", "medium", "pinterest"],
}

# ------------------------
# Safety & Compliance
# ------------------------
COMPLIANCE = {
    "check_before_post": True,
    "verify_links": True,
    "respect_rate_limits": True,
    "no_spam": True,
}

# Disclaimer for posts
POST_DISCLAIMER = """
---
About the Author: Joran is a California native married to a Chengdu local. He's been helping international travelers navigate China for over 10 years. For more practical guides, visit chinaboundtravel.com
"""