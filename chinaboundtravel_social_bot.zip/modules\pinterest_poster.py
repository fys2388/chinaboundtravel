# ============================================
# Pinterest Poster Module
# ============================================

import logging
import os
from config import PINTEREST_CONFIG, CONTENT_TEMPLATES

logger = logging.getLogger(__name__)

class PinterestPoster:
    """Pinterest posting functionality"""

    def __init__(self):
        self.config = PINTEREST_CONFIG
        self.template = CONTENT_TEMPLATES['pinterest']
        self.access_token = self.config['access_token']
        self.boards = self.config['board_ids']
        self._headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json"
        }

    def is_configured(self):
        """Check if Pinterest is properly configured"""
        return self.access_token != "YOUR_PINTEREST_ACCESS_TOKEN"

    def is_connected(self):
        """Check if connected to Pinterest API"""
        if not self.is_configured():
            return False

        try:
            import requests
            response = requests.get(
                "https://api.pinterest.com/v5/user_account",
                headers=self._headers,
                timeout=10
            )
            return response.status_code == 200
        except Exception as e:
            logger.error(f"Pinterest connection failed: {e}")
            return False

    def post(self, content):
        """
        Post content to Pinterest

        Args:
            content: dict with keys: title, description, image_path, board_name
        """
        if not self.is_connected():
            return {"success": False, "error": "Not connected or not configured"}

        try:
            import requests

            board_id = self._get_board_id(content.get('board_name', 'China Travel Guide'))

            image_path = content.get('image_path')
            if not image_path or not os.path.exists(image_path):
                logger.warning("No valid image provided for Pinterest")
                return {"success": False, "error": "Image required for Pinterest"}

            # Upload image
            image_data = {
                "title": self._format_title(content),
                "description": self._format_description(content),
            }

            # Create pin
            pin_data = {
                "board_id": board_id,
                "title": self._format_title(content),
                "description": self._format_description(content),
                "media_source": {
                    "source_type": "image_url",
                    "url": image_path
                }
            }

            response = requests.post(
                "https://api.pinterest.com/v5/pins",
                headers=self._headers,
                json=pin_data,
                timeout=30
            )

            if response.status_code in [200, 201]:
                data = response.json()
                logger.info(f"Posted to Pinterest: {data.get('id')}")
                return {
                    "success": True,
                    "id": data.get('id'),
                    "url": f"https://pinterest.com/pin/{data.get('id')}"
                }
            else:
                return {"success": False, "error": f"HTTP {response.status_code}"}

        except Exception as e:
            logger.error(f"Pinterest post failed: {e}")
            return {"success": False, "error": str(e)}

    def post_to_board(self, content, board_name):
        """Post to a specific board"""
        content['board_name'] = board_name
        return self.post(content)

    def _get_board_id(self, board_name):
        """Get board ID by name"""
        return self.boards.get(board_name, list(self.boards.values())[0])

    def _format_title(self, content):
        """Format pin title"""
        template = self.template['title_template']
        return template.format(title=content.get('title', ''))

    def _format_description(self, content):
        """Format pin description"""
        template = self.template['description_template']
        topic = content.get('topic', 'China travel')
        return template.format(topic=topic)

    def create_board(self, name, description=""):
        """Create a new Pinterest board"""
        if not self.is_connected():
            return {"success": False, "error": "Not connected"}

        try:
            import requests

            board_data = {
                "name": name,
                "description": description
            }

            response = requests.post(
                "https://api.pinterest.com/v5/boards",
                headers=self._headers,
                json=board_data,
                timeout=10
            )

            if response.status_code in [200, 201]:
                data = response.json()
                logger.info(f"Created board: {name} (ID: {data.get('id')})")
                return {
                    "success": True,
                    "id": data.get('id'),
                    "name": name
                }
            else:
                return {"success": False, "error": f"HTTP {response.status_code}"}

        except Exception as e:
            logger.error(f"Board creation failed: {e}")
            return {"success": False, "error": str(e)}