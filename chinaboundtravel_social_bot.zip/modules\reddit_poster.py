# ============================================
# Reddit Poster Module
# ============================================

import logging
from config import REDDIT_CONFIG, CONTENT_TEMPLATES

logger = logging.getLogger(__name__)

class RedditPoster:
    """Reddit posting functionality"""

    def __init__(self):
        self.config = REDDIT_CONFIG
        self.template = CONTENT_TEMPLATES['reddit']
        self.reddit = None
        self._connect()

    def _connect(self):
        """Connect to Reddit API"""
        try:
            import praw

            self.reddit = praw.Reddit(
                client_id=self.config['client_id'],
                client_secret=self.config['client_secret'],
                username=self.config['username'],
                password=self.config['password'],
                user_agent=self.config['user_agent']
            )

            logger.info("Reddit connection established")

        except Exception as e:
            logger.error(f"Reddit connection failed: {e}")
            self.reddit = None

    def is_connected(self):
        """Check if connected to Reddit"""
        return self.reddit is not None

    def post(self, content):
        """
        Post content to Reddit

        IMPORTANT: Reddit strict rule - NO external links allowed in posts
        Must use the诱导文案: "I wrote a fully detailed guide on my blog.
        Comment 'GUIDE' below, and I'll DM you the link."
        """
        if not self.is_connected():
            return {"success": False, "error": "Not connected"}

        try:
            title = self._format_title(content)
            body = self._format_body(content)

            subreddit_name = content.get('target_subreddit', 'travel')
            subreddit = self.reddit.subreddit(subreddit_name)

            submission = subreddit.submit(title=title, selftext=body)

            logger.info(f"Posted to Reddit: {submission.url}")

            return {
                "success": True,
                "url": submission.url,
                "id": submission.id
            }

        except Exception as e:
            logger.error(f"Reddit post failed: {e}")
            return {"success": False, "error": str(e)}

    def post_to_multiple_subreddits(self, content, subreddits=None):
        """Post to multiple subreddits"""
        if subreddits is None:
            subreddits = self.config['subreddits']

        results = []
        for subreddit_name in subreddits:
            content['target_subreddit'] = subreddit_name
            result = self.post(content)
            results.append({
                "subreddit": subreddit_name,
                "result": result
            })

        return results

    def _format_title(self, content):
        """Format post title"""
        template = self.template['title_template']
        return template.format(title=content.get('title', ''))

    def _format_body(self, content):
        """Format post body with诱导文案"""
        template = self.template['body_template']
        return template.format(
            title=content.get('title', ''),
            summary=content.get('summary', ''),
            no_link_message=self.config['no_link_message']
        )

    def get_post_stats(self, post_id):
        """Get statistics for a posted submission"""
        if not self.is_connected():
            return None

        try:
            submission = self.reddit.submission(id=post_id)
            return {
                "score": submission.score,
                "num_comments": submission.num_comments,
                "upvote_ratio": submission.upvote_ratio
            }
        except Exception as e:
            logger.error(f"Failed to get post stats: {e}")
            return None