# ============================================
# chinaboundtravel.com Social Media Bot
# Connection Test Script
# ============================================
# Tests connectivity to all platforms
# ============================================

import sys
import os
import time
import feedparser
import requests

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config

try:
    import praw
    PRAW_AVAILABLE = True
except ImportError:
    PRAW_AVAILABLE = False

try:
    from colorlog import ColoredFormatter
    COLORLOG_AVAILABLE = True
except ImportError:
    COLORLOG_AVAILABLE = False

# ------------------------
# Colors for output
# ------------------------
class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    RESET = '\033[0m'
    BOLD = '\033[1m'

def print_success(msg):
    print(f"{Colors.GREEN}[OK]{Colors.RESET} {msg}")

def print_error(msg):
    print(f"{Colors.RED}[FAIL]{Colors.RESET} {msg}")

def print_warning(msg):
    print(f"{Colors.YELLOW}[WARN]{Colors.RESET} {msg}")

def print_info(msg):
    print(f"{Colors.BLUE}[INFO]{Colors.RESET} {msg}")

def print_header(msg):
    print(f"\n{Colors.BOLD}{'='*60}{Colors.RESET}")
    print(f"{Colors.BOLD}{msg}{Colors.RESET}")
    print(f"{Colors.BOLD}{'='*60}{Colors.RESET}")

# ------------------------
# Test Functions
# ------------------------
def test_blog_rss():
    """Test blog RSS feed connectivity"""
    print_header("Testing Blog RSS Feed")

    try:
        print_info(f"Fetching: {config.BLOG_RSS}")
        response = requests.get(config.BLOG_RSS, timeout=10)

        if response.status_code == 200:
            feed = feedparser.parse(response.content)
            if feed.bozo == 0:
                print_success(f"RSS Feed accessible - {len(feed.entries)} articles found")
                print_info(f"Blog Title: {feed.feed.get('title', 'N/A')}")
                print_info(f"Last Updated: {feed.feed.get('updated', 'N/A')}")
                return True
            else:
                print_error("RSS Feed is malformed")
                return False
        else:
            print_error(f"HTTP Status: {response.status_code}")
            return False

    except requests.exceptions.Timeout:
        print_error("Connection timeout")
        return False
    except requests.exceptions.ConnectionError:
        print_error("Connection error - check URL")
        return False
    except Exception as e:
        print_error(f"Error: {str(e)}")
        return False

def test_reddit():
    """Test Reddit API connectivity"""
    print_header("Testing Reddit API (PRAW)")

    if not PRAW_AVAILABLE:
        print_warning("PRAW not installed - skipping Reddit test")
        print_info("Install with: pip install praw")
        return None

    try:
        reddit = praw.Reddit(
            client_id=config.REDDIT_CONFIG['client_id'],
            client_secret=config.REDDIT_CONFIG['client_secret'],
            username=config.REDDIT_CONFIG['username'],
            password=config.REDDIT_CONFIG['password'],
            user_agent=config.REDDIT_CONFIG['user_agent']
        )

        user = reddit.user.me()
        print_success(f"Reddit connected - Logged in as: {user}")

        subreddits = config.REDDIT_CONFIG['subreddits'][:3]
        print_info(f"Configured subreddits: {', '.join(subreddits)}...")

        return True

    except Exception as e:
        error_msg = str(e)
        if "INVALID_CLIENT_ID" in error_msg:
            print_error("Invalid client_id - check config.py")
        elif "INVALID_CLIENT_SECRET" in error_msg:
            print_error("Invalid client_secret - check config.py")
        elif "wrong password" in error_msg.lower():
            print_error("Invalid username or password")
        else:
            print_error(f"Error: {error_msg}")
        return False

def test_pinterest():
    """Test Pinterest API connectivity"""
    print_header("Testing Pinterest API")

    try:
        access_token = config.PINTEREST_CONFIG['access_token']
        if access_token == "YOUR_PINTEREST_ACCESS_TOKEN":
            print_warning("Access token not configured - skipping Pinterest test")
            print_info("Get credentials from: https://developers.pinterest.com/apps/")
            return None

        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        }

        response = requests.get(
            "https://api.pinterest.com/v5/user_account",
            headers=headers,
            timeout=10
        )

        if response.status_code == 200:
            data = response.json()
            username = data.get('username', 'N/A')
            print_success(f"Pinterest connected - Username: {username}")
            return True
        else:
            print_error(f"HTTP Status: {response.status_code}")
            return False

    except ImportError:
        print_warning("pinterest-api-sdk not installed - using basic HTTP test")
        if config.PINTEREST_CONFIG['access_token'] != "YOUR_PINTEREST_ACCESS_TOKEN":
            print_success("Token found in config - Pinterest module ready")
            return True
        return None
    except Exception as e:
        print_error(f"Error: {str(e)}")
        return False

def test_quora():
    """Test Quora connectivity"""
    print_header("Testing Quora")

    try:
        email = config.QUORA_CONFIG['email']
        if email == "YOUR_QUORA_EMAIL":
            print_warning("Quora credentials not configured - skipping test")
            print_info("Quora requires browser automation or cookies")
            return None

        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
        }

        response = requests.get("https://www.quora.com", headers=headers, timeout=10)

        if response.status_code == 200:
            print_success("Quora website accessible")
            print_info("Note: Full API requires browser automation (selenium)")
            return True
        else:
            print_error(f"HTTP Status: {response.status_code}")
            return False

    except Exception as e:
        print_error(f"Error: {str(e)}")
        return False

def test_medium():
    """Test Medium API connectivity"""
    print_header("Testing Medium API")

    try:
        token = config.MEDIUM_CONFIG['integration_token']
        if token == "YOUR_MEDIUM_INTEGRATION_TOKEN":
            print_warning("Integration token not configured - skipping test")
            print_info("Get token from: https://medium.com/me/settings/security")
            return None

        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
            "Content-Type": "application/json"
        }

        response = requests.get(
            "https://api.medium.com/v1/me",
            headers=headers,
            timeout=10
        )

        if response.status_code == 200:
            data = response.json()
            username = data.get('data', {}).get('username', 'N/A')
            name = data.get('data', {}).get('name', 'N/A')
            print_success(f"Medium connected - User: {name} (@{username})")
            return True
        else:
            print_error(f"HTTP Status: {response.status_code}")
            return False

    except Exception as e:
        print_error(f"Error: {str(e)}")
        return False

def test_dependencies():
    """Test if all required packages are installed"""
    print_header("Testing Dependencies")

    packages = {
        'requests': 'requests',
        'feedparser': 'feedparser',
        'schedule': 'schedule',
        'PIL': 'Pillow',
        'praw': 'praw',
    }

    all_ok = True
    for import_name, package_name in packages.items():
        try:
            __import__(import_name)
            print_success(f"{package_name} installed")
        except ImportError:
            print_error(f"{package_name} NOT installed - run: pip install {package_name}")
            all_ok = False

    return all_ok

# ------------------------
# Main Test Runner
# ------------------------
def run_all_tests():
    print("\n")
    print("="*60)
    print("  chinaboundtravel.com Social Bot - Connection Test")
    print("="*60)
    print(f"\nTesting: {config.BLOG_URL}")
    print(f"Author: {config.AUTHOR_NAME}")

    results = {}

    results['Dependencies'] = test_dependencies()
    results['Blog RSS'] = test_blog_rss()
    results['Reddit'] = test_reddit()
    results['Pinterest'] = test_pinterest()
    results['Quora'] = test_quora()
    results['Medium'] = test_medium()

    # Summary
    print_header("Test Summary")

    total = 0
    passed = 0
    skipped = 0

    for platform, result in results.items():
        total += 1
        if result is True:
            print_success(f"{platform}: Connected")
            passed += 1
        elif result is False:
            print_error(f"{platform}: Failed")
        else:
            print_warning(f"{platform}: Skipped (not configured)")
            skipped += 1

    print("\n" + "="*60)
    print(f"Results: {passed}/{total} passed, {skipped} skipped")
    print("="*60)

    if skipped > 0:
        print(f"\n{Colors.YELLOW}Configure the skipped services in config.py to enable full functionality{Colors.RESET}")

    return passed >= 2  # At least 2 services should work

if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)