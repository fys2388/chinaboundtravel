# ============================================
# chinaboundtravel.com Social Media Bot
# Main Scheduler
# ============================================
# Phase 1: Framework only - posting logic reserved
# ============================================

import sys
import os
import time
import logging
import schedule
import feedparser
from datetime import datetime
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config

# Import platform modules
try:
    from modules.reddit_poster import RedditPoster
    REDDIT_AVAILABLE = True
except ImportError:
    REDDIT_AVAILABLE = False

try:
    from modules.pinterest_poster import PinterestPoster
    PINTEREST_AVAILABLE = True
except ImportError:
    PINTEREST_AVAILABLE = False

try:
    from modules.quora_poster import QuoraPoster
    QUORA_AVAILABLE = True
except ImportError:
    QUORA_AVAILABLE = False

try:
    from modules.medium_poster import MediumPoster
    MEDIUM_AVAILABLE = True
except ImportError:
    MEDIUM_AVAILABLE = False

# ------------------------
# Logging Setup
# ------------------------
def setup_logging():
    """Configure logging for the bot"""
    log_config = config.LOG_CONFIG

    logging.basicConfig(
        level=getattr(logging, log_config['level']),
        format=log_config['format'],
        handlers=[
            logging.FileHandler(log_config['file']),
            logging.StreamHandler()
        ]
    )

    return logging.getLogger(__name__)

logger = setup_logging()

# ------------------------
# Content Fetcher
# ------------------------
class ContentFetcher:
    """Fetch latest content from blog RSS feed"""

    def __init__(self):
        self.blog_url = config.BLOG_URL
        self.rss_url = config.BLOG_RSS
        self.posts = []

    def fetch_posts(self):
        """Fetch posts from RSS feed"""
        try:
            logger.info(f"Fetching posts from {self.rss_url}")
            feed = feedparser.parse(self.rss_url)

            posts = []
            for entry in feed.entries[:20]:  # Latest 20 posts
                post = {
                    'title': entry.get('title', ''),
                    'link': entry.get('link', ''),
                    'summary': self._clean_summary(entry.get('summary', '')),
                    'published': entry.get('published', ''),
                    'tags': [tag.term for tag in entry.get('tags', [])],
                }
                posts.append(post)

            self.posts = posts
            logger.info(f"Fetched {len(posts)} posts from RSS")
            return posts

        except Exception as e:
            logger.error(f"Failed to fetch posts: {e}")
            return []

    def _clean_summary(self, summary):
        """Clean HTML from summary"""
        import re
        clean = re.sub('<[^<]+?>', '', summary)
        clean = clean.replace('&nbsp;', ' ')
        clean = clean.strip()
        if len(clean) > 300:
            clean = clean[:300] + '...'
        return clean

    def get_post_by_topic(self, topic):
        """Get a post matching a specific topic"""
        for post in self.posts:
            title_lower = post['title'].lower()
            if topic.lower() in title_lower:
                return post
        return self.posts[0] if self.posts else None

# ------------------------
# Platform Manager
# ------------------------
class PlatformManager:
    """Manage all platform connections"""

    def __init__(self):
        self.platforms = {}

        if REDDIT_AVAILABLE:
            self.platforms['reddit'] = RedditPoster()

        if PINTEREST_AVAILABLE:
            self.platforms['pinterest'] = PinterestPoster()

        if QUORA_AVAILABLE:
            self.platforms['quora'] = QuoraPoster()

        if MEDIUM_AVAILABLE:
            self.platforms['medium'] = MediumPoster()

    def get_available_platforms(self):
        """Return list of available platforms"""
        return list(self.platforms.keys())

    def post_content(self, platform, content):
        """Post content to specified platform"""
        if platform not in self.platforms:
            logger.warning(f"Platform {platform} not available")
            return False

        try:
            poster = self.platforms[platform]
            result = poster.post(content)
            logger.info(f"Posted to {platform}: {result}")
            return result
        except Exception as e:
            logger.error(f"Failed to post to {platform}: {e}")
            return False

# ------------------------
# Daily Posting Manager
# ------------------------
class PostingManager:
    """Manage daily posting schedule"""

    def __init__(self):
        self.fetcher = ContentFetcher()
        self.manager = PlatformManager()
        self.daily_counts = {
            'reddit': 0,
            'pinterest': 0,
            'quora': 0,
            'medium': 0,
        }

    def reset_daily_counts(self):
        """Reset daily posting counts"""
        self.daily_counts = {k: 0 for k in self.daily_counts}
        logger.info("Daily counts reset")

    def can_post(self, platform):
        """Check if can post to platform today"""
        if platform not in self.daily_counts:
            return False
        limit = config.DAILY_LIMITS.get(platform, 0)
        return self.daily_counts[platform] < limit

    def increment_count(self, platform):
        """Increment posting count"""
        if platform in self.daily_counts:
            self.daily_counts[platform] += 1
            logger.info(f"{platform}: {self.daily_counts[platform]}/{config.DAILY_LIMITS[platform]} posts today")

    def run_morning_batch(self):
        """Run morning posting batch (10:00 AM)"""
        logger.info("Running morning posting batch")
        self._run_posting_batch("morning")

    def run_afternoon_batch(self):
        """Run afternoon posting batch (4:00 PM)"""
        logger.info("Running afternoon posting batch")
        self._run_posting_batch("afternoon")

    def _run_posting_batch(self, batch_name):
        """Execute posting batch"""
        posts = self.fetcher.fetch_posts()

        if not posts:
            logger.warning("No posts available for distribution")
            return

        platforms = self.manager.get_available_platforms()
        logger.info(f"Available platforms: {', '.join(platforms)}")

        # Phase 1: Only fetch and display, no actual posting
        logger.info(f"Phase 1: Fetched {len(posts)} posts, ready for distribution")
        for post in posts[:3]:
            logger.info(f"  - {post['title'][:50]}...")

        logger.info("Phase 1 complete - Full posting enabled in Phase 2")

# ------------------------
# Scheduler Setup
# ------------------------
def setup_schedule(posting_manager):
    """Setup posting schedule"""

    for posting_time in config.POSTING_TIMES:
        time_str = f"{posting_time.hour:02d}:{posting_time.minute:02d}"

        if posting_time.hour == 10:
            schedule.every().day.at(time_str).do(
                posting_manager.run_morning_batch
            )
        elif posting_time.hour == 16:
            schedule.every().day.at(time_str).do(
                posting_manager.run_afternoon_batch
            )

        logger.info(f"Scheduled posting at {time_str} Beijing time")

    # Reset counts daily at midnight
    schedule.every().day.at("00:00").do(posting_manager.reset_daily_counts)

def run_scheduler():
    """Main scheduler loop"""
    logger.info("Starting chinaboundtravel Social Bot...")
    logger.info(f"Blog: {config.BLOG_URL}")
    logger.info(f"Author: {config.AUTHOR_NAME}")

    posting_manager = PostingManager()
    setup_schedule(posting_manager)

    logger.info("Scheduler running. Press Ctrl+C to stop.")

    try:
        while True:
            schedule.run_pending()
            time.sleep(1)
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
        sys.exit(0)

def run_once():
    """Run posting cycle once (for testing)"""
    logger.info("Running single posting cycle...")
    posting_manager = PostingManager()
    posting_manager.run_morning_batch()

# ------------------------
# Main Entry Point
# ------------------------
def main():
    """Main entry point"""
    import argparse

    parser = argparse.ArgumentParser(description="ChinaBound Travel Social Bot")
    parser.add_argument('--once', action='store_true', help='Run posting cycle once')
    parser.add_argument('--continuous', action='store_true', help='Run continuous scheduler')

    args = parser.parse_args()

    if args.once:
        run_once()
    else:
        run_scheduler()

if __name__ == "__main__":
    main()